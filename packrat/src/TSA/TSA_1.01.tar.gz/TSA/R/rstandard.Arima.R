`rstandard.Arima` <-
function(model,...){residuals(model)/model$sigma^.5}

